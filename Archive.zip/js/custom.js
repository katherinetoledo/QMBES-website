// console.log("before");
// var feed = new Instafeed({
//     get: 'user',
//     accessToken: '5787145626.1677ed0.d281eed9e8ed44c88485f2be120b5ce6',
//     userId: '5787145626',
//     limit: 3,
//     resolution: "low_resolution",
//     template: '<img src="{{image}}" alt="instafeed_img"/>'
// });
// feed.run();

// ,
//         // filter: function(image) {
//         //     return image.tags.indexOf('#gallery') >= 0;
//         //   },
//         after: function () {
//             // $('#instafeed > div:nth-child(1)').addClass('active');
//         }

//https://codeofaninja.com/tools/find-instagram-user-id
//http://instagram.pixelunion.net/

//access token 5787145626.1677ed0.d281eed9e8ed44c88485f2be120b5ce6
//user id 5787145626