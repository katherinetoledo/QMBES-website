$('.carousel-control.left').click(function() {
  $('#carouselCompetitions').carousel('prev');
});

$('.carousel-control.right').click(function() {
  $('#carouselCompetitions').carousel('next');
});